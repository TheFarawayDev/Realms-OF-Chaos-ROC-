# Realms of Chaos

**By TheFarawayDev** - a Minecraft mod (Fabric **and** Forge) for **Minecraft 26.3**.

> A mashup of mythologies forged into weapons, with several starting points, bosses and paths to travel.

This release implements the **Greek mythology** path (the part of the design that is fully specified).
The other four starting points (Norse, Egyptian, Celtic, Japanese) and the optional side-realms (Hellish, Heavenly,
Phobias, Community weapons, Voodoo & Tarot) are not in yet.

## Release channel

The `VERSION` file at the repo root sets the version and channel for both loaders, the in-game Codex, the GitHub
release and the download page: `1.2.0-alpha` and `1.2.0-beta` are published as pre-releases, `1.2.0` as a full release.
The current build is an **Alpha**.

## What's in 1.2.0

* **Parry, riposte, momentum.** Fighting the realms' creatures is more than trading blows, and none of it needs a
  key of its own.
  * **Parry.** Tap sneak - or raise a shield - just as a blow would land and it is turned aside: no harm, the
    attacker reels (slowed, weakened, and open), and the next blow within three seconds is a **riposte**, half as
    hard again. A bolt parried goes back to whoever loosed it. Even a god's blow can be met. The moment is seven
    ticks; a tap that parries nothing has to be waited out.
  * **Momentum.** Every blow landed without being hit builds it, to five; each point adds 4% to every blow. Being
    struck loses it all.
  * **Exposure and the plunge.** A blow on a reeling enemy counts half as much again; a blow struck while falling
    shakes everything round the one it lands on.
  * **A combat meter** above the hotbar shows momentum, whether a parry is to hand, and a riposte waiting. It can be
    turned off in Settings.
* **Sentinels strike heavy blows.** Those that fight hand to hand - on any level past the first, and every elite -
  draw back for most of a second before a blow nearly twice as hard. It can be seen coming, stepped away from, or
  parried, and a heavy blow parried leaves the sentinel reeling twice as long.
* **A seal's boon.** Whoever breaks a seal is offered three boons and takes one - Vigour, Edge, Swiftness, Ward,
  Keen Eye (longer to parry in), Thirst (a heart back per sentinel felled) or Fortune (more from every cache). The
  same boon can be taken up to four times. Boons last until the passage is behind you.
* **A frame for every phase.** A god's bar is plain metal in its first phase, studded with crystal while its aegis
  is up - with a pylon on the plaque for each still standing - and toothed, cracked and glowing in its wrath, with
  the rings of floor still left. The aegis and the wrath are each announced on a card of their own.
* **A better chart.** Rooms that matter carry a sign (a cross for a seal, a box once it is broken, a diamond for a
  cache, an arch for the gate); wide rooms are drawn wide; a mark along the top for every level of the passage and
  along the bottom for every seal. **A shrine shows the whole of its level** on the chart of whoever it blesses.
* **The gate faces the way in.** The Gate of Ascent stands across the doorway a climber comes through, in an arch
  of its own, instead of always facing north and south.
* **A bestiary** (`/roc bestiary`, or from the Codex): every kind of sentinel you have felled, a tower to a page,
  with what it does and how many have fallen. Tall rooms are hung with lamps on chains, each tower's own kind.

* **Its own things on the screen.** Nothing the mod shows takes over the view.
  * **Tips are cards.** A tip is a small card at the top of the screen with up to three lines on it, shown for a few
    seconds; cards wait their turn instead of replacing one another. Any title too long to fit a small window is
    written on a card too. Short ones (*Victory!*) stay titles.
  * **Boss bars are drawn.** A god's bar is its tower's own frame and emblems, a fill coloured by phase, a mark
    where its aegis rises (65%) and where its wrath begins (30%), a gem lit for each phase reached, and its name in
    block lettering.
  * **The cast bar is opt-in.** A god's move is no longer named for everyone above the hotbar. Turn the cast bar on
    (Codex > Settings, or `/roc casts`) and each move is named on a bar that fills as the god winds up.
  * **Settings and insight menus**, each with its own panel: `/roc settings`, `/roc insight`, or from the Codex.
  * All of it is fonts whose letters are pictures (`tools/hud_art.py`), composed on the server, so it needs nothing
    on the client but the mod and is the same on Fabric and Forge.
* **Gods that remember.** Every trial is watched, player by player: how much harm was done from afar or hand to
  hand, blows taken on a shield, wounds mended mid-fight, time spent out of reach. A habit shown in trial after
  trial is learnt, through three levels, and the next god already has an answer: shots count for less and it
  closes in on a **marksman**; its guard lashes back at a **duellist**; its blows knock a **shield-bearer**'s
  shield aside; a marked strike falls where a **mender** stops to heal; a **runner** is hauled back. A card says
  what a god knows of you as the trial starts and what was learnt as it ends. Drop a habit and it is forgotten, a
  trial at a time. This is on top of the stance a god takes within a single trial.
* **Rooms that are not all alike.** Passage rooms are low (5), tall (7) or great (8 high); about a third of the
  ordinary ones are a step wider (11 across); and a room may have its corners cut, a ring of columns to the
  ceiling, or a floor sunk a step with stairs out of it. Arenas are always the biggest room there is. Levels are
  built as solid slabs twelve deep, so a tall room is still inside its own level.
  * **Stairwells.** Nearly every level has one: a great hall with a flight of steps at either side up to a loft
    across its north end, and a cache on the loft.
  * **Three more trap halls**, none of which can be switched off: a **spike hall** (two colours of tile, each
    colour's spikes up in turn), a **flame hall** (vents erupt a row at a time, the fire walking down the hall) and
    a **blade hall** (a blade sweeping from wall to wall and back). Each warns before it strikes, and they hurt
    more the deeper the level.

* **Trials in three phases.** A god fights as itself down to 65% of its health, and no single blow carries it past
  that mark or the next.
  * **Aegis (65%).** It raises shield pylons round the floor - two on Easy, three on Normal, four on Hard, one more
    for a group of three - and nothing can hurt it while one stands. Right-click a pylon to strike it; three blows
    break it. The boss bar says *Aegis*, light runs from each pylon to the god, and an aegis nobody breaks fades
    after 75 seconds. When it goes, the floor starts to shift.
  * **Wrath (30%).** A last stand (two seconds untouchable, two sentinels, its signature move and its line's
    ability back to back), and then the floor is lost ring by ring from the wall inward: the paving turns to
    charged stone under Zeus, black ice under Poseidon, magma under Hades, and standing on it hurts. Strikes fall
    from above - lightning, the sea bursting up, burning stone - each marked by a ring on the floor for a second
    and a half before it lands. The middle nine blocks are never lost.
  * **The floor is given back.** Every block a fight changes is put back the moment the god falls, and a floor
    left scorched by a server stop is rebuilt the next time anyone sets foot on it.
* **Gods that adapt.**
  * **To your gear.** When a trial is called the god measures everyone on the floor: the hardest-hitting weapon in
    each pack (a relic counts for its level, stars and temper), the enchantments on it, and armour with its
    enchantments. The strongest challenger sets the bar. Gear past what the floor expects gives the god up to 2.2
    times its health and up to 1.6 times its damage; poor gear never makes it weaker. The Trial Altar's screen
    tells you what it will make of you before you begin.
  * **To how you fight.** Between phases it looks at how the last one went. Mostly shot at: it turns shots aside
    (they do 40%) and throws itself at whoever stands off. Mostly struck hand to hand: its guard lashes back and
    the floor erupts more often. A phase that was over quickly makes the next one heavier - another pylon, more
    strikes, a faster collapse - and a long one lighter.
  * **To the difficulty.** Easy, Normal and Hard set its health (85%, 100%, 125%), how long it waits between
    moves, and how many pylons it raises.
  * **In its looks.** Every god's skin has been redrawn with more detail - the mark of its tower on its back, gold
    on the arms of the stronger gods, a cape on the three greatest of each tower - and each god now has three
    skins: itself, lit with runes behind its aegis, and cracked open with fire inside in its wrath.
* **The mod's own menu artwork.** The Codex's tower plans, the forge, the passage map, the seal, the deck, the
  party, the chronicle and the Field Tower Bag no longer look like chests. Each has its own panel - a dark field
  with a header in the menu's colour and its emblem, and a parchment half for your inventory - unused slots are
  blank tiles of the panel and meters are gems instead of glass panes. It is done with the mod's own resources (a
  font whose letters are whole panels, and item models for the tiles and gems), so nothing extra is needed on the
  client and it is the same on Fabric and Forge. Every slot is a hole in the artwork, so an icon can never be
  hidden by it. `art/renders/ui-panels.png` shows three of them.
* **Passages of one to ten levels.** How many levels lie between two boss floors is decided by the world's seed:
  one to four low in a tower, two to seven in the middle, four to ten near the top (about 190 levels across the
  three towers in a typical world). Every level has a name - **7-B2** is passage 7, wing B, level 2 - shown on its
  bar and title. Wings are three levels long and each is built from a different set of its tower's stone. Levels
  after a passage's first may be a row and a column larger.
* **No waiting at the gate.** The next level is built in the background, about four milliseconds a tick, while
  you explore the one you are on, and a passage's first level is built while the trial below it is fought. Arrive
  early and only what is left is finished on the spot.
* **The Passage Chart: a map with fog of war.** Everyone is handed a chart on entering a passage. It is an
  ordinary map item, drawn by the mod: blank parchment to begin with, each room inked in when you first walk into
  it - its kind by colour, its doorways, a broken seal turning green - with a white mark where you stand. `/roc
  chart` gives a new one.
* **Four puzzle rooms**, each keeping a cache locked until it is solved (for everyone at once; they lock and
  scramble again when a passage re-seals):
  * **Vault** - nine glyph tiles; pressing one turns it and its neighbours; light all nine.
  * **Chime room** - ring four crystals before the first falls silent (eleven seconds low in a tower, seven high).
  * **Beam room** - turn two mirrors until the beam reaches the receiver.
  * **Trembling floor** - a ring of plates of which one path holds. It glimmers every six seconds and has to be
    walked in order from its first plate; a wrong plate throws you off.
* **Two more trap halls.** A **crusher hall** marks a row and a second later brings the ceiling down on it, row
  after row; the row that just fell is the safe one. A **dart hall** has marked tiles that loose arrows from the
  walls at whoever treads on them.
* **Things to find.** **Urns** can be smashed: most hold a little loot, some nothing, a few a sentinel. **Lore
  tablets** tell a line of the tower's story (24 in all) and give a little experience the first time. Each tower
  has its own **brazier**.
* **Mastery.** A point for every god woken and every passage walked, spent in the Codex (or `/roc skills`) on
  twelve skills of three ranks each: *Combat* - Might, Swiftness, Focus, Reach; *Survival* - Vigor, Guard,
  Steadiness, Second Wind; *Exploration* - Cartographer (the chart sketches rooms next door), Signal, Scavenger,
  Pathfinder. The tree can be taken apart and re-spent at any time.
* **Sixty-three sentinels.** Each tower now has twenty-one kinds instead of six. Every kind has a role (soldier,
  caster, skirmisher, brute, mystic, Keeper) and most have one **trait** that no other kind in their tower has. The
  deeper a level, the more kinds it fields.
  * *They cover for each other:* a **shield-bearer** turns blows from its front and shelters whoever stands beside
    it; a **warden** takes half of every blow that lands on an ally; a **standard-bearer** strengthens everyone near
    (and they falter when it falls); a **dancer** trades places with a wounded ally and mends it; a **singer** stands
    one fallen ally back up; a **berserker** grows stronger each time an ally falls.
  * *They make trouble:* **bombers** run at you, hiss and burst; **binders** root you (Zeus), haul you in
    (Poseidon) or blind you (Hades); **sowers** leave patches of ground that hurt; **snipers** aim along a line of
    light before one heavy shot; **thieves** knock your weapon out of your hand and into your pack (nothing is ever
    lost); **silencers** stop your relic's move for six seconds; **mirages** split into three, two of them harmless
    copies; **chargers** run you through; **heralds** sound an alarm that wakes the rooms next door.
* **Layered skins.** Gods and sentinels are drawn with the player model, so a skin's outer layer stands proud of
  the body: pauldrons, breastplates, greaves, cloaks, tabards, sashes, belts, furs, chains, bandoliers, masks,
  plumes. All 63 sentinels and all 45 gods wear some.
* **Bolts are models.** Staff bolts, the gods' shots, thrown relics and thrown cards are no longer a flat picture
  facing the camera: they are drawn as a 3D model lying along the line of flight, nose first, turning as they go.
* **Craters.** A bolt from a relic of level 3 or more breaks the ground where it lands - on anything, not only on
  an enemy. The crater is one block wide at level 3, two at 6, three at 9, and one more with three stars; the blast
  hurts what is near. **Out in the world a crater stays** (where you could have dug it yourself: not in adventure
  mode or spawn protection). Inside the realms the towers mend themselves: there a crater is one block deep and
  closes after ten seconds, lifting out anyone standing in it. Chests and unbreakable blocks are never taken.
* **Rune chambers.** The trap rooms of the passages are now traps with a puzzle in them. A rune stone stands on a
  pillar in each corner; step onto the marked square in the middle and the doorways close and water rises a layer
  at a time. The runes light up in an order, again and again - press them (right-click) in that order and the room
  drains, opens, and pays each player in it forge material, once. A wrong rune starts the order again and the
  water leaps up a layer. It is a trap, not a grave: once full it hurts its catch for a quarter of a minute and
  then lets go by itself, unpaid. It resets when nobody is left inside, never springs for someone who has solved
  it, and a room left flooded by a server stop is put right when someone next walks in.
* **A sidebar.** `/roc sidebar` (or the switch in the Codex) turns on a panel at the side of the screen: the tower
  and floor, a trial's phase and health, pylons standing, the ring of floor that is left, the hub's tier, the
  compass's signal, today's bounties and your party. Each player has their own; it never touches the world's
  scoreboard.
* **The compass scans. Nothing warps.** The Compass of Chaos no longer carries anyone to the hub, and neither do
  the Codex or `/roc hub` from the world outside.
  * Right-click begins a **scan** of 60 to 90 seconds, read above the hotbar while the compass is in hand: an
    arrow (up is straight ahead), a distance, five bars of signal and the time left. Every two or three seconds the
    needle rolls and picks a target - the nearer and weightier, the likelier.
  * Most rolls are rough, off by as much as the signal is poor. Now and then one is a **Clean Lock** (exact, with
    a trail of light) or a **Static Surge** (nonsense). The longer a scan runs the truer it reads, and its best
    reading is written to chat when it ends.
  * Sneak and right-click turns it to what it looks for: the way to the hub, the keystone shrines, or relays and
    waygates.
  * **Signal:** a bare compass reads 0.35. Each **Relay Tower Core** within 96 blocks adds 0.15 (up to three) and
    each hub tier 0.05; rain costs 0.1, thunder 0.2, being deep underground 0.15, and another player's **Signal
    Jammer** within 64 blocks costs 0.5 (not its owner's or their party's).
* **A field network.** New players get a **Field Tower Bag** holding two Relay Tower Cores and a **Waygate
  Obelisk**. All three blocks can be crafted, set down, broken and carried, and where they stand is saved with the
  world.
  * The bag keeps its contents in itself, so they survive wherever the bag goes. Sneak and right-click a block to
    set down the first network block inside without opening it. A bag cannot go inside a bag.
  * A waygate sends you to any other obelisk you have touched, or - once a Ruined Gate knows you - to the Hub of
    Realms. Choose on its screen, then stand still for **five seconds**: move or be hit and it lets go. A journey
    costs one ender pearl, taken on arrival.
* **The hub grows.** The **Heart of the Hub** opens Hub Command. Everyone on the world shares one hub and anyone
  can hand over what the next of its **five tiers** asks for.
  * II: steadier compasses, a hub that mends whoever stands in it, and the **Bounty Board**. III: six-row Field
    Bags, and the hub lifts every harm. IV: three-second waygates and a needle that rolls every two seconds. V: free
    waygates.
  * The Bounty Board posts three bounties a day, the same for everyone - sentinels felled, seals broken, trials
    won, pylons shattered, caches opened. Each player earns them for themselves and is paid in forge materials.
* **Custom screens, not just chests.** The Codex, the Climber's Handbook, the Oracle's Chronicle, the Trial Altar
  and the party are real screens - a title, text, pictures of items and buttons - built on the game's own dialog
  system, so they work the same on Fabric and Forge. Chapters of the story are read on screen, page by page. The
  screens with moving parts (the forge's strike bar, the passage map, a tower's floor plan) are still chest menus.
* **A tutorial.** A new player is shown the **Climber's Handbook** a few seconds after they first join: nineteen
  topics, from getting in to reading a fight, always there in the Codex. After that, a **tip** appears the first
  time each thing happens - the first Ruined Gate, the first altar, the first seal, the first eruption - once each.
* **Climb together.** Up to four players can form a **party** (Codex -> Party, or `/roc party invite <player>`,
  `/roc party accept`, `/roc party leave`).
  * A party enters a tower on the floor of its **highest member**, and anyone in it may begin that floor's trial.
  * Progress is always each player's own. Everyone on the floor when a god falls is credited, but nobody goes up
    past a floor until they have beaten its god themselves - with help or without - and walked its passage. A
    friend who got ahead while you were away can come back down and help you through yours.
  * Floors you were carried past are still yours to do: alone, you enter on your own floor, and can also return to
    any floor you earned with the party.
  * **Everyone gets their own loot.** Each victor's drops can only be picked up by them: the floor's forge material
    every time, and the god's relic (and its cards) the first time *they* beat it. Passage treasure is a **cache**
    that gives every player their own share, once.
* **The tower adapts.** A trial faced by a group is harder: +60% health and +15% damage for each challenger after
  the first (up to four), and each sealed chamber wakes an extra sentinel per extra player (up to two). A god that
  keeps beating you relents: 8% less health for each defeat, up to three, wiped by a victory. A passage that others
  broke open **seals itself again** for a player who has not walked it yet.
* **The walls hold.** Inside the hub, the towers and the passages, survival players are in adventure mode - they
  can fight, open and use everything, but not break or place blocks - and get survival back the moment they leave.
  Creative players are not restricted.
* **Sentinels: the passages' own enemies.** Eighteen kinds, six to a tower, each with its own look:

  | | Soldier | Caster | Skirmisher | Brute | Mystic | Keeper |
  | --- | --- | --- | --- | --- | --- | --- |
  | Zeus | Storm Hoplite | Sky Archer | Harpy | Thunder Brute | Storm Augur | Keeper of the Sky |
  | Poseidon | Tide Hoplite | Siren | Telchine | Reef Brute | Tide Priest | Keeper of the Tides |
  | Hades | Shade | Lampad | Fury | Tartarus Brute | Necromancer | Keeper of the Shades |

  Soldiers close in (the Shade steps behind you). Casters stand off and shoot. Skirmishers are quick and leap at
  you (a Fury's blow sets you alight). Brutes hit slowly and throw you back. **Mystics** help the rest: the Storm
  Augur quickens and emboldens them, the Tide Priest heals them, the Necromancer raises Shades. A **Keeper** holds
  every seal and uses a small version of one of its tower's moves. **Elites** glow, take half as much again to
  bring down and always drop forge material.
  How strong a sentinel is follows its place: every passage further up the tower, and every level further into a
  passage, makes them tougher and brings more kinds - skirmishers from the second passage, brutes from the middle
  of the tower, mystics near the top.
* **Fights that move.** Every heavy move now **breaks the ground**: chunks of whatever the floor is made of are
  thrown into the air (they are for show, and vanish when they land). Once a god is enraged **the floor erupts**
  under its challengers every few seconds - dust and a rumble for a second, then anyone still standing there is
  thrown into the air. At a fifth of its health a god makes a **last stand**: for two seconds nothing can touch it,
  two of its tower's sentinels answer its call, and then its signature move and its line's ability follow one
  after the other.
* **A story.** Chaos, the oldest thing there is, has woken and is unmaking the world one story at a time. The
  gods of the sky, the sea and the dead shut themselves in three towers to hold it off - and have forgotten why.
  You do not slay them: every trial wakes a god, and a relic is its thanks. The story is told by the **Oracle** in
  nineteen chapters, each a real book: her letter (given on first join), books found in the ruins, a chapter for
  each stretch of each tower (after 5, 10 and 15 of its gods are awake - the last in the king's own words) and an
  epilogue. **The Oracle's Chronicle** (her flame in the hub, or the Codex) lists them, hands out the ones you
  have earned, and always says what to do next.
* **The way in has to be found.** The gates were broken on purpose. Until a gate knows you, the realms are closed
  and the **Compass of Chaos** scans for the nearest **Ruined Gate** in the Overworld.
  * A Ruined Gate is a broken plaza round a dead arch, with a campfire still smoking. Its chest holds the story so
    far and three **seekers** - compasses that each point to the nearest shrine of one keystone.
  * The three **keystones** lie in three kinds of shrine elsewhere in the world: the **Shrine of the Sky** (a
    white temple), the **Shrine of the Tides** (a ring of prismarine round a pool) and the **Shrine of the Shades**
    (standing stones round a crypt you walk down into).
  * Right-click the gate's **pedestal** with each keystone to set it in the arch. Three keystones wake the gate
    (for everyone); stepping through it **attunes** you: from then on every gate lets you through and a Waygate
    Obelisk will send you to the hub.
  * Ruins are placed from the world seed - there is always a Ruined Gate within about 800 blocks and each kind of
    shrine within about 700 - and are raised on the surface when a player first comes near. Players who had
    already woken a god before this update, and players in creative mode, are let in without a gate.
* **A livelier hub.** The Oracle's Flame burns at its heart. Beside each tower gate stand two **echoes** of its
  gods - the first you will meet and the king at the top - which hold their relics and turn their heads to watch
  you. A canal rings the plaza, bridged by the four paths; cherry trees stand in four gardens; pilgrims wander,
  cats sit about and allays drift overhead; fireflies rise over the gardens.
* **The Hub of Realms** - a plaza with four gates: **Zeus** (north), **Poseidon** (east), **Hades** (west), and the
  **exit** back to where you came from (south).
* **Three towers of 15 floors**, one per god line. Every floor is its own enclosed arena holding one god; floor 1 has
  the starter (rank 15) and floor 15, the open summit, has the final god (rank 1). Beat a floor's god and its
  **Gate of Ascent** opens.
* **Every floor is different.** Ten terrain layouts (flat, mounds, pillared hall, pit, dais, waves, moat, terraces,
  split level, ziggurat, summit) are combined with four material tiers per tower:

| Floors | Tower of Zeus | Tower of Poseidon | Tower of Hades |
|---|---|---|---|
| 1-5 | Foothills of Olympus | The Sunlit Shallows | Fields of Asphodel |
| 6-10 | The Marble Halls | The Prismarine Halls | Tartarus |
| 11-14 | The Cloud Sanctum | The Trench | Halls of the Dead |
| 15 | Summit of Olympus | Throne of the Deep | Throne of the Underworld |

* **Passages between the floors.** The Gate of Ascent no longer takes you straight up: the first time, it leads
  into a **passage** (14 per tower, 42 in all). A passage is not one level but several, stacked one above the
  other - **two levels** in the lower third of a tower, **three** above - and each level is a maze of rooms and
  corridors with a gate at its far end that stays shut until every **seal** on that level is broken (two seals
  low in the tower, three in the middle, four near the summit). A level's gate leads up to the next level; the
  last one leads to the next floor. Each level is harder than the one below, and each passage harder than the last.
  * **Procedural.** Each passage is laid out from the world seed - which rooms connect, where the way in, the gate
    and the seals are, what every room is - so every world's towers are different, and every level of every
    passage is different. Mazes grow with the tower: 4 x 4 rooms on the lower floors, 5 x 5 above, and 6 x 6 for
    the last level of the highest passages. A tower has 879 rooms in all.
  * **Rooms.** Every proper room has a shallow dome, a band of trim and sconces in its walls. There are sealed
    chambers, **arenas** (on the levels above the first: an elite and its pack guard a richer cache), **gardens**,
    **libraries** (with a working enchanting table), **pools**, treasure rooms (a cache with a share for every player: this tier's forge material,
    experience bottles, food and metal; in Hades' tower sometimes a tarot card), one **shrine** (right-click: full health, harmful effects
    cleared and three minutes of the tower's favour, once every ten minutes per player), trapped rooms (scorching
    tiles and webs), plain rooms and corridors.
  * **Seals and guardians.** Walking into a sealed chamber wakes its sentinels: a Keeper, one more for each tier of
    the tower and one more again for each level into the passage (more for a group), with an elite among them on a
    passage's last level. A breaking seal goes with a shockwave that throws up the floor and staggers anyone close. While any stand the seal is warded. Then right-click the seal and **strike it apart** - a
    quick-time bar: click when the hammer is on the mark. A perfect strike cracks it twice, a good one once, a miss
    stings.
  * **Finding your way.** The Codex opens the **passage map** while you are in one: one slot per room, filled in as
    you explore, with unexplored rooms hinted where a door leads on. The Compass of Chaos points to the nearest
    unbroken seal, then to the gate (sneak + right-click still travels to the hub). A bar at the top counts seals.
  * A passage you have walked is remembered: next time the Gate of Ascent takes you straight up. Players inside
    together share its seals; a player who arrives later, not having walked it, finds it sealed again.
* **Living floors.** Floors change during a trial: when the god drops below two thirds health the terrain shifts,
  one block at a time, into a second shape (a pit rises into a dais, a hall folds into terraces), and shifts back
  below one third; the upper floors also keep shifting on a timer. Anything standing on rising ground is carried up,
  no step ever exceeds one block, and the floor settles back into its own design when the fight ends.
* **Furnished rooms.** Every floor has engaged columns between its windows, a ribbed ceiling with hanging lights, a
  processional path from the gates, and props that match its tier (azaleas and lanterns in the foothills, braziers
  of soul fire in Tartarus, sculk and soul lanterns in the Trench...).
* **Nine kinds of weapon** instead of 45 swords: blades, daggers (fast), polearms (long reach), heavy weapons (slow,
  crushing), scythes (every hit sweeps), and four ranged kinds - staffs (cast bolts), bows (loose arrows), thrown
  weapons (thunderbolts, javelins, shards) and relics such as a chalice, a conch or pan pipes (pulse their power
  around you). Right-click attacks with ranged kinds; sneak + right-click is their Divine Surge.
* **Ranged gods.** A god fights the way its weapon does: gods with a ranged kind keep their distance and shoot.
  Hades also throws tarot cards.
* **Signature moves.** Every god has a move of its own, named on screen as it winds up (*"Zeus readies Wrath of
  Olympus!"*), and alternates it with its line's ability. There are fourteen kinds of move - storm, charge, volley,
  vortex, shockwave, blink, mend, slumber, reap, hex, frost, gale, ward and eruption - and each also carries the
  god's own hit power and curse. Eruptions and hexes land a moment late, so they can be stepped out of.
* **Livelier gods.** Melee gods lunge at a target that keeps its distance; ranged gods hop away when crowded (and
  back towards the middle if cornered). At half health a god is **enraged**: it glows, roars everyone back a step,
  moves faster and casts sooner.
* **Rematches.** A god you have beaten can be called back from its altar for another fight. A rematch drops the
  floor's forge material again - but no second relic, cards or deck.
* **The relic casts its god's move.** Right-click with a melee relic (sneak + right-click with a ranged one) casts
  the same signature move, on a 12-second recharge. Forging matters to it: **three stars empower** the move (+50%
  damage) and **five stars awaken** the relic so the move echoes a second time. Every fourth hit in a row with any
  relic is a **flourish** (+50%). Moves never hurt other players or your own pets.
* **Weapon levelling and forging.** A relic gains experience from every kill made with it (level 1-10, +8% damage a
  level). At a **Forge of Chaos** (two stand in the hub; also `/roc forge` and the Codex) you forge up to five stars
  onto it (+10% damage and faster recharge each; star N needs weapon level 2N). The forge screen shows the star
  track, what the next star changes in numbers, the signature move and its perks, where each material drops, and
  an **Infuse** button that pours your own experience levels into the relic (30 weapon XP a level).
* **Forging is struck, not clicked.** Pressing *Forge* pays the price and starts a quick-time round of three
  strikes: a hammer runs back and forth along the bottom row, and each click is judged by where it is - on the
  mark is perfect, beside it good, elsewhere a miss. The star is forged whatever happens; the strikes decide the
  finish. **Masterwork** (no misses, two perfect) *tempers* the star for +2% damage and gives 60 weapon XP; fine
  work (at most one miss) gives 30; rough work gives nothing extra. The later stars are struck faster. A star that
  was not tempered can be struck again with the **Temper** button (2 of the tower's first material; only a
  masterwork takes). Closing the screen mid-round ends it as it stands - nothing paid is lost. Stars are paid for with what the
  gods of the weapon's own tower drop - every tier of a tower has its own material, so the higher stars send you
  higher up:

  | Tier (floors) | Zeus | Poseidon | Hades | Drop per god |
  | --- | --- | --- | --- | --- |
  | 1 (1-5) | Laurel Leaf | Sea Glass | Asphodel Petal | 2 |
  | 2 (6-10) | Marble Shard | Reef Scale | Tartarus Cinder | 2 |
  | 3 (11-14) | Cloud Silk | Trench Ink | Obol of the Dead | 3 |
  | 4 (summit) | Spark of Olympus | Pearl of the Deep | Ember of the Underworld | 2 |

  Star 1 costs 3 of tier 1; star 2: 3 of tier 1 + 2 of tier 2; star 3: 4 of tier 2 + 1 of tier 3; star 4: 4 of
  tier 3; star 5: 3 of tier 3 + 1 of the summit essence. One climb of a tower drops enough to fully forge one
  weapon, and a fully forged relic shimmers.
* **Tarot.** The gods of Hades' tower drop the 22 Major Arcana (three copies of each of their cards). A card is
  played with right-click and spent. Hades drops Death and the **Deck of Fate**: a stack that never runs out -
  right-click draws a random card, sneak + right-click lets you choose one (the deck then rests longer).

  | Card | What it does |
  | --- | --- |
  | 0 The Fool | Iron armour and an iron sword, and a journey to the nearest village or mineshaft |
  | I The Magician | Strength II-III, and 20 logs |
  | II The High Priestess | A bubble for 10 seconds: no harm gets in and monsters are pushed out |
  | III The Empress | Grows the plants around you; Luck |
  | IV The Emperor | No knockback and +8 armour for 45 seconds |
  | V The Hierophant | Hero of the Village |
  | VI The Lovers | Regeneration for you, and buffs for every player near you |
  | VII The Chariot | Speed III, and you step up full blocks |
  | VIII Strength | Strength and Resistance |
  | IX The Hermit | Takes you to your own private island in a pocket dimension; play it again (or use the gate) to return |
  | X Wheel of Fortune | Luck at its maximum |
  | XI Justice | Everything around you glows through walls |
  | XII The Hanged Man | Monsters stop targeting you for 30 seconds (gods are not fooled) |
  | XIII Death | Hands you a Totem of Undying |
  | XIV Temperance | Full health, hunger and saturation |
  | XV The Devil | Burns your inventory; for 30 seconds everything you pick up becomes the item in your off hand |
  | XVI The Tower | Carries you to another god tower: the one whose relics you hold fewest of |
  | XVII The Star | Experience and a little Luck |
  | XVIII The Moon | Summons five illusions that cannot hurt you; slay them all for a reward |
  | XIX The Sun | Burns nearby foes; Regeneration |
  | XX Judgement | Full health and a moment of Resistance |
  | XXI The World | Speed, Strength, Regeneration and Resistance |

  The Tower reads item tags: every relic weapon is tagged with the tower it comes from
  (`realms_of_chaos:relics/zeus`, `.../poseidon`, `.../hades`; `realms_of_chaos:relics` holds them all). The card
  counts the relics you carry by tag, never picks the tower you are standing in, and of the rest sends you to the
  one you hold fewest relics of (ties fall at random). A new mythology only needs a tag of its own to join in.

  The Devil spares worn armour, the Deck of Fate and the chosen item, refuses to be played with an empty off hand,
  and is never dealt by a blind draw from the Deck - you have to choose it.
* **Voodoo dolls** (crafted: string over wheat-pin-wheat over wheat; the pin is an iron nugget, cobweb, rotten flesh
  or blaze powder). Right-click a creature to bind the doll, then right-click to stab: the creature is hurt from up
  to 64 blocks away. Pain wounds, Binding slows and weakens, Rot withers, Embers burns. Gods take half and ignore
  the curses.
* **45 gods** - each is a boss with its own look *and* an animated relic weapon:

| Floor | Rank | Zeus line | Poseidon line | Hades line |
|---|---|---|---|---|
| 15 | 1 | Zeus | Poseidon | Hades |
| 14 | 2 | Athena | Amphitrite | Persephone |
| 13 | 3 | Apollo | Triton | Zagreus |
| 12 | 4 | Dionysus | Chrysaor | Thanatos |
| 11 | 5 | Artemis | Cymopoleia | Hypnos |
| 10 | 6 | Ares | Rhode | Melinoe |
| 9 | 7 | Hermes | Pegasus | Macaria |
| 8 | 8 | Asclepius | Benthesikyme | Hecate |
| 7 | 9 | Hebe | Halia | Morpheus |
| 6 | 10 | Phobos | Nereus | Nyx |
| 5 | 11 | Deimos | Proteus | Erinyes |
| 4 | 12 | Hygeia | Palaemon | Moirai |
| 3 | 13 | Pan | Thetis | Keres |
| 2 | 14 | Nike | Galene | Oneiroi |
| 1 (start) | 15 | **Iris** | **Galatea** | **Charon** |

Signature moves, floor by floor:

| Floor | Zeus line | Poseidon line | Hades line |
|---|---|---|---|
| 15 | Zeus: *Wrath of Olympus* | Poseidon: *Earthshaker* | Hades: *Gates of Tartarus* |
| 14 | Athena: *Aegis* | Amphitrite: *Queen's Tide* | Persephone: *Winter's Harvest* |
| 13 | Apollo: *Sunburst Volley* | Triton: *Call of the Deep* | Zagreus: *Stygian Dash* |
| 12 | Dionysus: *Bacchic Revel* | Chrysaor: *Golden Rush* | Thanatos: *Final Harvest* |
| 11 | Artemis: *Hunter's Moon* | Cymopoleia: *Stormwave* | Hypnos: *Lullaby* |
| 10 | Ares: *Warpath* | Rhode: *Rain of Roses* | Melinoe: *Ghostlight* |
| 9 | Hermes: *Windstep* | Pegasus: *Skyward Gale* | Macaria: *Blessed End* |
| 8 | Asclepius: *Panacea* | Benthesikyme: *Undertow* | Hecate: *Crossroads Hex* |
| 7 | Hebe: *Cup of Youth* | Halia: *Seafoam Chill* | Morpheus: *Waking Dream* |
| 6 | Phobos: *Terror Strike* | Nereus: *Old Man of the Sea* | Nyx: *Starfall* |
| 5 | Deimos: *Dread Harvest* | Proteus: *Shapeshift* | The Erinyes: *Vengeance* |
| 4 | Hygeia: *Cleansing Ward* | Palaemon: *Anchor Drop* | The Moirai: *Severed Thread* |
| 3 | Pan: *Panic* | Thetis: *Silver Rain* | The Keres: *Carrion Feast* |
| 2 | Nike: *Victory Rush* | Galene: *Stillwater* | The Oneiroi: *Nightmare* |
| 1 | Iris: *Prism Gust* | Galatea: *Pearl Frost* | Charon: *Ferryman's Toll* |

* **In-game UI instead of chat** - nothing the mod tells you goes to chat:
  * **Codex of Chaos** (item or `/roc`), a double-chest screen: the three towers side by side with climb meters,
    and a page per tower that draws it floor by floor with tier labels. Click any floor you have reached to travel
    there; travel to the hub or leave the realms from the main page.
  * **Trial Altar menu**: right-click a floor's altar to see its god and begin the trial, or ascend once it is won;
    a strip along the bottom shows the floors around you.
  * **Tower bar**: a bar at the top of the screen shows the tower, floor and tier you are on.
  * **Titles and action bar** for arrivals, trials, victories and short notices.
  * **Advancements tab** with one advancement per god.
* **First-join welcome** - a thank-you title, plus the Codex, the Compass of Chaos and a Field Tower Bag.

## How to play

1. Join a world. You are given the Codex, the Compass of Chaos, a Field Tower Bag and the Oracle's letter. Read
   the letter, then right-click the **Compass of Chaos** and follow its scan to the nearest **Ruined Gate**. Take
   the three seekers from its chest, follow each to its shrine for a keystone, set the keystones at the pedestal
   and step through the gate. (To come back later, walk through the gate again or set down a Waygate Obelisk near
   home and channel at it.)
2. In the hub, walk into a tower gate. You arrive on the floor you are working on.
3. Right-click the floor's **Trial Altar** and press **Begin the trial**. (Trials need a difficulty above Peaceful.)
4. Defeat the god - break its shield pylons when it raises its aegis at 65%, and stay off the lost edge of the
   floor and out of the marked rings in its wrath at 30%. It drops its **relic weapon** (scaled by rank, with a hit power of its own and its god's
   signature move) and its tier's forge material, and the **Gate of Ascent** at the far side of the floor opens for you.
5. Step through the gate into the **passage**: explore it, break its seals, and take the gate at its far end up to
   the next floor.
6. Climb. The three towers are independent, and progress is saved per player.
7. To go home, take the south gate in the hub, the Codex's *Leave the Realms* button, or `/roc leave`.

Each line fights differently: **Zeus** calls lightning, **Poseidon** drags you in and crashes tidal waves over you,
**Hades** drains your life and (for the top gods) raises wither skeletons. Bosses raise their arms and gather
particles for about a second before a big attack.

**No getting stuck:** no step on any floor is taller than one block and nothing stands inside the fight ring, floors
are fully enclosed, bosses that end up off their floor, inside a block or unable to reach you are put back, and a
player who is stuck in a block or falls out is returned to the floor's arrival pad.

## Install

| Loader | Needs |
|---|---|
| Fabric | Minecraft 26.3, Java 25, Fabric Loader >= 0.20.1, Fabric API 0.166.2+26.3 (or newer for 26.3) |
| Forge | Minecraft 26.3, Java 25, Forge 66.1.9 (or newer for 26.3) |

Drop the matching `realms-of-chaos-<loader>-<version>+mc26.3.jar` into your `mods` folder.

Updating from 1.0 / 1.1: the hub is rebuilt and the old arenas are replaced by the towers automatically the next
time someone enters them. Progress is kept: you arrive on the floor matching the gods you have already defeated.

## Building from source

```bash
JAVA_HOME=/path/to/jdk-25 ./build.sh
```

* `common/` - loader-independent code and assets, shared by both builds
* `fabric/`, `forge/` - thin loader entrypoints and Gradle builds
* `tools/generate.py` - the god roster (single source of truth) plus the generator for textures, skins, models,
  lang, advancements and the website's roster
* `site/` - the download page (GitHub Pages)
* `tools/make_font.py` - builds `site/ChaosBlocks.ttf`, the square block lettering of the site's titles (an original
  typeface; needs `pip install fonttools`)
* `art/atlases/` - every texture the mod ships, gathered into atlases (items, animated item frames, blocks, skins,
  portraits, weapon designs), each also at 4x, with an `index.json` naming every tile
* `art/weapon-designs/` - a sheet of every weapon silhouette, including designs for mythologies that are not in the
  mod yet. Japanese, planned next: a curved katana, wakizashi, tanto, nodachi, naginata, yari, kusarigama, sai,
  kanabo, nunchaku, yumi, kunai, shuriken and tessen. Others: battleaxe, Mjolnir, khopesh, claymore, halberd, mace,
  crossbow. Their
  textures already ship under `textures/item/design/`.

### Self-test

The mod contains a developer self-test that only runs when the JVM has `-Droc.selftest=true`. It exercises the mod
on a real server: data loading, the hub, building and walking every floor of every tower, a full climb of all three
towers through the altar menu (with rematches) and all 42 passages, the Ruined Gate and its keystones, the story's
chapters, the hub's residents, all sixty-three sentinels and their traits, craters, the custom screens and their buttons, the tutorial, impacts, the
floor's eruptions and the gods' last stands, the three phases of a trial (health gates, pylons, stances, the collapsing floor and its restoration, strikes), gear and difficulty scaling,
the compass scanner, relays and jammers, waygates, the Field Tower Bag, hub tiers and bounties, the rune chambers, the sidebar, level counts and names, building ahead, the four puzzle rooms, crusher and dart halls, urns and tablets, the Passage Chart, the mastery tree, the menu artwork, cards and tips, the drawn boss bar and the opt-in cast bar, settings, the gods' memory of each player, room shapes and stairwells, the spike, flame and blade halls, parries, ripostes, momentum and plunges, heavy blows, boons, the gate's facing, the shrine's chart, the bestiary, the frames of each phase, parties, group scaling and per-player loot, the wall protection (built, checked room by room for reachability,
seals struck, guardians, shrine, map), every god's signature move, the relic moves, the forging quick-time rounds,
tier materials, each tarot card, the Codex, leaving the realms, the welcome and the anti-stuck safeguards.

```bash
cd forge && ./gradlew runGameTestServer && cat run/roc-selftest.txt
```

License: MIT. Greek mythology belongs to everyone.
